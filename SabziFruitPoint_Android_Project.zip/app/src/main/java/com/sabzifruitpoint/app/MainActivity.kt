package com.sabzifruitpoint.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity

data class Product(val name: String, val price: Int, val unit: String, var qty: Int = 0)

class MainActivity : android.app.Activity() {
    private val products = mutableListOf(
        Product("🥔 आलू", 30, "1 kg"),
        Product("🍅 टमाटर", 40, "1 kg"),
        Product("🧅 प्याज", 35, "1 kg"),
        Product("🍎 सेब", 120, "1 kg"),
        Product("🍌 केला", 50, "1 दर्जन"),
        Product("🍊 संतरा", 90, "1 kg")
    )
    private lateinit var totalText: TextView
    private lateinit var cartLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "🛒 Sabzi & Fruit Point"
            textSize = 25f
            setTextColor(Color.rgb(46,125,50))
            gravity = Gravity.CENTER
            setPadding(0,10,0,15)
        }
        root.addView(title)

        val offer = TextView(this).apply {
            text = "🔥 ताज़े फल और सब्जियाँ  |  FREE HOME DELIVERY"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(12,18,12,18)
            setBackgroundColor(Color.rgb(232,245,233))
        }
        root.addView(offer)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        products.forEachIndexed { index, p ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8,18,8,18)
            }
            val info = TextView(this).apply {
                text = "${p.name}\n₹${p.price} / ${p.unit}"
                textSize = 17f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val minus = Button(this).apply { text = "−" }
            val qty = TextView(this).apply {
                text = p.qty.toString()
                textSize = 18f
                gravity = Gravity.CENTER
                setPadding(12,0,12,0)
            }
            val plus = Button(this).apply { text = "+" }

            minus.setOnClickListener {
                if (p.qty > 0) p.qty--
                qty.text = p.qty.toString()
                updateTotal()
            }
            plus.setOnClickListener {
                p.qty++
                qty.text = p.qty.toString()
                updateTotal()
            }
            row.addView(info); row.addView(minus); row.addView(qty); row.addView(plus)
            list.addView(row)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        totalText = TextView(this).apply {
            text = "कुल: ₹0"
            textSize = 21f
            gravity = Gravity.CENTER
            setPadding(10,14,10,14)
            setTextColor(Color.rgb(46,125,50))
        }
        root.addView(totalText)

        val order = Button(this).apply {
            text = "📲 WhatsApp पर Order करें"
            textSize = 17f
        }
        order.setOnClickListener { sendWhatsAppOrder() }
        root.addView(order)

        setContentView(root)
    }

    private fun updateTotal() {
        val total = products.sumOf { it.price * it.qty }
        totalText.text = "कुल: ₹$total"
    }

    private fun sendWhatsAppOrder() {
        val selected = products.filter { it.qty > 0 }
        if (selected.isEmpty()) {
            Toast.makeText(this, "पहले सामान Cart में जोड़ें", Toast.LENGTH_SHORT).show()
            return
        }
        val total = selected.sumOf { it.price * it.qty }
        val items = selected.joinToString("%0A") {
            "${it.name} - ${it.qty} x ₹${it.price}"
        }
        val message = "नमस्ते, मुझे यह सामान चाहिए:%0A$items%0A%0Aकुल: ₹$total%0A%0Aडिलीवरी पता: "
        val url = "https://wa.me/918296980576?text=$message"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "WhatsApp उपलब्ध नहीं है", Toast.LENGTH_LONG).show()
        }
    }
}
